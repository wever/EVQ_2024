## --- Load the pyGDM modules
from pyGDM2 import structures
from pyGDM2 import materials
from pyGDM2 import fields
from pyGDM2 import propagators
from pyGDM2 import core
from pyGDM2 import linear
from pyGDM2 import visu
from pyGDM2 import tools

## --- we will use numpy as well
import numpy as np
import matplotlib.pyplot as plt


################### MATERIAL E FORMA ########################

################ RADIACAO ELETROMAGNETICA ####################


########################## CALCULO ###########################



######################## ANALISE #############################

## get all simulated configurations, each corresponding to a spectrum
fieldKwargs = tools.get_possible_field_params_spectra(sim)

config_idx = 0
wl1, spectrum = tools.calculate_spectrum(sim,
                    fieldKwargs[config_idx], linear.extinct)


plt.plot(wl1, spectrum.T[0], 'g-', label='gold sphere/ext.')
plt.plot(wl1, spectrum.T[1], 'b-', label='gold sphere/scat.')
plt.plot(wl1, spectrum.T[2], 'r-', label='gold sphere/abs.')


plt.xlabel("wavelength (nm)")
plt.ylabel("cross section (nm^2)")
plt.legend(loc='best', fontsize=8)

plt.show()


