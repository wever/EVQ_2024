#!/bin/bash


im_dir=.
scene_dir=${im_dir}/MVE
../mve/apps/makescene/makescene -i ${im_dir} ${scene_dir} &> log1.log

../mve/apps/sfmrecon/sfmrecon --track-thres-factor=100 --always-full-ba ${scene_dir} &> log2.log


../mve/apps/dmrecon/dmrecon  -s2 ${scene_dir} &> log3.log


../mve/apps/scene2pset/scene2pset -F2 ${scene_dir} ${scene_dir}/pset-L2.ply &> log4.log


../mve/apps/fssrecon/fssrecon --interpolation=cubic ${scene_dir}/pset-L2.ply ${scene_dir}/surface-L2.ply &> log5.log


../mve/apps/meshclean/meshclean -t10 ${scene_dir}/surface-L2.ply ${scene_dir}/surface-L2-clean.ply &> log6.log

