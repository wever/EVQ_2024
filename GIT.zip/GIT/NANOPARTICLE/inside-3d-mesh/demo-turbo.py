import sys
import numpy

import os

import stlparser
from is_inside_mesh import is_inside_turbo as is_inside

import matplotlib.pyplot as plot
from mpl_toolkits.mplot3d import Axes3D

def writeXYZ(fileName, points, label=["X"], w="w"):
    outFile = fileName
    x, y , z = points
    xPoints = len(x)
    yPoints = len(y)
    zPoints = len(z)
    if xPoints == yPoints == zPoints:
        nPoints = xPoints
    else:
        print("DIFFERENT NUMBERS OF X Y Z")
    if label == ["X"]:
        label = ["X"]*nPoints
    if not os.path.exists("fileName"):
        print("SAVING FILE ..", outFile)
        f = open(outFile, w)
    else:
        print("!!!OUTPUT FILE ALREADY EXIST!!!")
        exit()
    for i in range(nPoints):
        if i == 0:
            print(nPoints, "\ntitle", file=f, end="\n")
        args = (label[i], round(x[i], 8), round(y[i], 8), round(z[i], 8))
        print('{0:<10} {1:<25} {2:<25} {3:<25}'.format(*args), file=f)
    return 


def main():
    # Load the input mesh as a list of triplets (ie. triangles) of 3d vertices
    try:
        triangles = numpy.array([X for X, N in stlparser.load(sys.stdin)])
    except stlparser.ParseError as e:
        sys.stderr.write(f'{e}\n')
        sys.exit(0)

    # Compute uniform distribution within the axis-aligned bound box for the mesh
    triangles *= 2
    min_corner = numpy.amin(numpy.amin(triangles, axis = 0), axis = 0)
    max_corner = numpy.amax(numpy.amax(triangles, axis = 0), axis = 0)
    P = (max_corner - min_corner) * numpy.random.random((100000, 3)) + min_corner

    # Filter out points which are not inside the mesh
    P = P[is_inside(triangles, P)]
    writeXYZ('nanoparticle_random.xyz', (P[:,0], P[:,1], P[:,2]))
    print("MinX = ", min(P[:,0]), " MaxX = ", max(P[:,0]))
    print("MinY = ", min(P[:,1]), " MaxY = ", max(P[:,1]))
    print("MRnZ = ", min(P[:,2]), " MaxZ = ", max(P[:,2]))
    print("\nNUMBER OF PARTICLES = ", len(P[:,0]), "\n")



    # Display
    fig = plot.figure()
    ax = plot.axes(projection = '3d')
    ax.scatter(P[:,0], P[:,1], P[:,2], lw = 0., c = 'k')
    plot.show()
	


if __name__ == '__main__':
	main()
