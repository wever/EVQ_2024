import numpy as np
import os
import sys
 
 
def writeXYZ(fileName, points, label=["X"]):
    outFile = fileName
    x, y , z = points
    xPoints = len(x)
    yPoints = len(y)
    zPoints = len(z)
    if xPoints == yPoints == zPoints:
        nPoints = xPoints
    else:
        print("DIFFERENT NUMBERS OF X Y Z")
    if label == ["X"]:
        label = ["X"]*nPoints
    if not os.path.exists("fileName"):
        print("SAVING FILE ..", outFile)
        f = open(outFile, "w")
    else:
        print("!!!OUTPUT FILE ALREADY EXIST!!!")
        exit()
    for i in range(nPoints):
        if i == 0:
            print(nPoints, "\n", file=f, end="\n")
        args = (label[i], round(x[i], 8), round(y[i], 8), round(z[i], 8))
        print('{0:<10} {1:<25} {2:<25} {3:<25}'.format(*args), file=f)
    return x, y, z
 
 
def readXYZ(fileName):
    inpFile = fileName
    n = 0
    l = []
    x = []
    y = []
    z = []
    scale = 5
    with open(inpFile) as f:
        data = f.readlines()
        for line in data:
            line = line.strip()
            if line:
                if n == 0:
                    nAtoms = int(line.split()[0])
                    print(n)
                    n += 1
                elif n == 1:
                    n += 1
                    pass
                elif n > 2:
                    (label, xCoord , yCoord, zCoord) = line.strip().split()
                    l.append(label)
                    x.append(float(xCoord)*scale)
                    y.append(float(yCoord)*scale)
                    z.append(float(zCoord)*scale)
                n += 1
            else:
                pass
 
    return nAtoms, l, x, y, z
 
inpFile = 'nanoparticle_random.xyz'
print("READING FILE...", inpFile)
nAtoms, label, x, y, z = readXYZ(inpFile)

coord = np.array([x,y,z]).T

centroid = coord.mean(0)

x, y, z = (coord - centroid).T

print('Dist.x: ', x.max() - x.min())
print('Dist.y: ', y.max() - y.min())
print('Dist.z: ', z.max() - z.min())

print()
print("NUMBER OF POINTS...", nAtoms)
print(len(x))
 
dr0 = 1.0
rCut = 5.0
rCut2 = rCut**2
N = 30
step = 4
scaleGrid = 2
xGrid = []
yGrid = []
zGrid = []
#print(x)
#outFile = sys.argv[2]
#writeXYZ(outFile, (x,y,z))
 
for i in range(-N, N+step,step):
    dx0 = i*dr0
    for j in range(-N, N+step,step):
        dy0 = j*dr0
        for k in range(-N, N+step,step):
            dz0 = k*dr0
            for l in range(nAtoms):
                #print(l)
                dx1 = (x[l]-dx0)**2
                dy1 = (y[l]-dy0)**2
                dz1 = (z[l]-dz0)**2
                if (dx1+dy1+dz1 < rCut2):
                    args = (l + 1)
                    # print('{0:>12}'.format(args))
                    xGrid.append(dx0*scaleGrid)
                    yGrid.append(dy0*scaleGrid)
                    zGrid.append(dz0*scaleGrid)
                    break


print('FINAL # GRID POINTS: ', len(xGrid))
print('Dist.x: ', max(xGrid) - min(xGrid))
print('Dist.y: ', max(yGrid) - min(yGrid))
print('Dist.z: ', max(zGrid) - min(zGrid))

print()
outFile = 'nanoparticle.xyz'
writeXYZ(outFile, (xGrid,yGrid,zGrid))
